TODO
----
* add the debug output
* add the user info, category name and comment counts to the posts
* add the counts to the categories in the sidebar
* add the "single" page template
* add a "default" profile picture for users with a null image

DONE
----
* Set up github repo
* Wireframe the basic templates
* Design the database structure
* Build the basic HTML and CSS of the home page
* "chunk" the header, sidebar and footer
* make the dates pretty
* add the list of users, categories and tags to the sidebar